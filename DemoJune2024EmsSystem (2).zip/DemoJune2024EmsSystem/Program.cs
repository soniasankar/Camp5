using DemoJune2024EmsSystem.Repository;
using DemoJune2024EmsSystem.Service;

namespace DemoJune2024EmsSystem
{
    public class Program
    {
        public static void Main(string[] args)
        {
            var builder = WebApplication.CreateBuilder(args);

            // Add services to the container.
            builder.Services.AddControllersWithViews();

            // 1- Add connection string
            var connectionString = builder.Configuration.GetConnectionString("ConnectionMVCWin");
            builder.Services.AddSingleton(connectionString);    
            // 2 - Register Service and Repository
            builder.Services.AddScoped<IEmployeeRepository,EmployeeRepositoryImpl>();   
            builder.Services.AddScoped<IEmployeeService,EmployeeServiceImpl>(); 
            var app = builder.Build();

            // Configure the HTTP request pipeline.
            if (!app.Environment.IsDevelopment())
            {
                app.UseExceptionHandler("/Home/Error");
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseStaticFiles();

            app.UseRouting();

            app.UseAuthorization();

            app.MapControllerRoute(
                name: "default",
                pattern: "{controller=Employee}/{action=Index}/{id?}");

            app.Run();
        }
    }
}
