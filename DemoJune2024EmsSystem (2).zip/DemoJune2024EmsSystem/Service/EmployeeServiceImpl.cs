﻿using DemoJune2024EmsSystem.Models;
using DemoJune2024EmsSystem.Repository;

namespace DemoJune2024EmsSystem.Service
{
    public class EmployeeServiceImpl : IEmployeeService
    {
        // Fields
        private readonly IEmployeeRepository _employeeRepository;

        // DI
        public EmployeeServiceImpl(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;   
        }
        // 2 -Add  Employee
        public void AddEmployee(Employee employee)
        {
           // throw new NotImplementedException();
		   _employeeRepository.AddEmployee(employee);	
        }

		public void DeleteEmployee(int? empId)
		{
		//	throw new NotImplementedException();
			_employeeRepository.DeleteEmployee(empId);	
		}

		// 4 - List all Departments
		public List<Department> GetAllDepartments()
		{
			//throw new NotImplementedException();
			return _employeeRepository.GetAllDepartments();	
		}

		// 1- Get All Employees
		public IEnumerable<Employee> GetAllEmployees()
        {
            return _employeeRepository.GetAllEmployees();
        }

        // 5 - Search DepartmentId
		public Department GetDepartmentById(int? deptId)
		{
		//	throw new NotImplementedException();
		return _employeeRepository.GetDepartmentById(deptId);
			
		}

		// 3 - Search By Id
		public Employee GetEmployeeById(int? empId)
        {
            //throw new NotImplementedException();
			return _employeeRepository.GetEmployeeById(empId);	
        }

		public void UpdateEmployee(Employee employee)
		{
		//	throw new NotImplementedException();
			_employeeRepository.UpdateEmployee(employee);	
			
		}
	}
}
