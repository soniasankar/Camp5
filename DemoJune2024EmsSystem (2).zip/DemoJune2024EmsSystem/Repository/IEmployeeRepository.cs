﻿using DemoJune2024EmsSystem.Models;

namespace DemoJune2024EmsSystem.Repository
{
    public interface IEmployeeRepository
    {
        // Insert Employee
        void AddEmployee(Employee employee);  
        // List of Employees
        IEnumerable<Employee> GetAllEmployees();

        // Search by EmployeeId
        Employee GetEmployeeById (int? empId);  

        // Get All Departments
        List<Department> GetAllDepartments();   
        // Get DepartmentById
        Department GetDepartmentById (int? deptId);

        // Update Employee
        void UpdateEmployee (Employee employee);    
        // Delete Employee
        void DeleteEmployee(int? empId); 

    }
}
