﻿using DemoJune2024EmsSystem.Models;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.InteropServices;

namespace DemoJune2024EmsSystem.Repository
{
    public class EmployeeRepositoryImpl : IEmployeeRepository
    {
        // DI
        private readonly string connectionString;

        //Constructor Injection
        public EmployeeRepositoryImpl(IConfiguration configuration)
        {
            connectionString = configuration.GetConnectionString("ConnectionMVCWin");
        }
        // To insert an Employee
        
        public void AddEmployee(Employee employee)
        {

            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_AddEmployee", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Name", employee.Name);
                cmd.Parameters.AddWithValue("@Gender",employee.Gender);
                cmd.Parameters.AddWithValue("@Designation", employee.Designation);
                cmd.Parameters.AddWithValue("@Salary", employee.Salary);
                cmd.Parameters.AddWithValue("@DOB",employee.DOB);   
                cmd.Parameters.AddWithValue("@DepartmentId",employee.DepartmentId); 
                con.Open();
                cmd.ExecuteNonQuery();  
                con.Close();    
            }
        }

		public void DeleteEmployee(int? empId)
		{
			using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_DeleteEmployee", con);
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id", empId);
                con.Open(); 
                cmd.ExecuteNonQuery();
                con.Close();    
            }
		}

		public List<Department> GetAllDepartments()
		{
			List<Department> departments = new List<Department>();
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                SqlCommand command = new SqlCommand("sp_GetAllDepartments", connection);
                command.CommandType = CommandType.StoredProcedure;
                connection.Open();  
                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Department department = new Department
                        {
                            DepartmentId = Convert.ToInt32(reader["DepartmentId"]),
                            DepartmentName = Convert.ToString(reader["DepartmentName"])
                        };
                        departments.Add(department);
                    }
                }
                connection.Close(); 
            }
            return departments;
		}

		// Get All Employees

		public IEnumerable<Employee> GetAllEmployees()
        {
            // Declare variable for return list of employees
            List<Employee> employees = new List<Employee>();
            try
            {
                using (SqlConnection con = new SqlConnection(connectionString))
                {
                    SqlCommand cmd = new SqlCommand("sp_SelectEmployees1", con);
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    con.Open();
                    SqlDataReader dr = cmd.ExecuteReader(); 

                    while (dr.Read())
                    {
                        Employee employee = new Employee(); 
                        employee.Id = Convert.ToInt32(dr["Id"].ToString());
                        employee.Name = dr["Name"].ToString();
                        employee.Gender = dr["Gender"].ToString();
                        employee.Designation = dr["Designation"].ToString();
                        employee.Salary =Convert.ToInt32(dr["Salary"].ToString());
                        employee.DOB = Convert.ToDateTime(dr["DOB"]);
                        employee.DepartmentId = Convert.ToInt32(dr["DepartmentId"].ToString());

                        // Department Details
                        employee.Department = new Department();
                        employee.Department.DepartmentId = Convert.ToInt32(dr["DepartmentId"].ToString());
                        employee.Department.DepartmentName = dr["DepartmentName"].ToString();

                        // Add to List
                        employees.Add(employee);    
                    }
                    con.Close();
                }
                return employees;
            }
            catch (Exception ex) 
            {
                return null;
            }
        }

		public Department GetDepartmentById(int? deptId)
		{
            Department dept = new Department();
            using (SqlConnection con = new SqlConnection(connectionString))
            {
				SqlCommand command = new SqlCommand("sp_GetDepartmentsById", con);
                command.CommandType = System.Data.CommandType.StoredProcedure;
                command.Parameters.AddWithValue("DepartmentId",deptId); 
				con.Open();
                SqlDataReader dr = command.ExecuteReader(); 
                while (dr.Read())
                {
                    dept.DepartmentId = Convert.ToInt32(dr["DepartmentId"].ToString()) ;
                    dept.DepartmentName = dr["DepartmentName"].ToString();
                }
               con.Close ();    
			}
            return dept;
		}

		// Get Employee Id
		public Employee GetEmployeeById(int? empId)
        {
            Employee emp = new Employee();  
            using (SqlConnection con = new SqlConnection(connectionString))
            {
                SqlCommand cmd = new SqlCommand("sp_GetEmployeeById", con);    
                cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("Id", empId);
                con.Open(); 
                SqlDataReader dr = cmd.ExecuteReader(); 
                while(dr.Read())
                {
                    emp.Id = Convert.ToInt32(dr["Id"].ToString());
                    emp.Name = dr["Name"].ToString();
                    emp.Gender = dr["Gender"].ToString();
                    emp.Designation = dr["Designation"].ToString();
                    emp.Salary = Convert.ToInt32(dr["Salary"].ToString());
                    emp.DOB = Convert.ToDateTime(dr["DOB"]);
                    emp.DepartmentId = Convert.ToInt32(dr["DepartmentId"].ToString());
                }
                con.Close() ;   
            }
            return emp; 
        }

		public void UpdateEmployee(Employee employee)
		{
            using (SqlConnection con = new SqlConnection(connectionString))
            {
				SqlCommand cmd = new SqlCommand("sp_EditEmployee", con);
				cmd.CommandType = System.Data.CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@Id",employee.Id); 
				cmd.Parameters.AddWithValue("@Name", employee.Name);
				cmd.Parameters.AddWithValue("@Gender", employee.Gender);
				cmd.Parameters.AddWithValue("@Designation", employee.Designation);
				cmd.Parameters.AddWithValue("@Salary", employee.Salary);
				cmd.Parameters.AddWithValue("@DOB", employee.DOB);
				cmd.Parameters.AddWithValue("@DepartmentId", employee.DepartmentId);
				con.Open();
				cmd.ExecuteNonQuery();
				con.Close();
			}
		}
	}
}
