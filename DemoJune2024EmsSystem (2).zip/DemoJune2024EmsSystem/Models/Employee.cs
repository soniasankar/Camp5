﻿using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace DemoJune2024EmsSystem.Models
{
    public class Employee
    {
        // fields
        [Key]
        public int Id { get; set; }
        [Required(ErrorMessage ="Name is Required.")]
        [RegularExpression(@"^[A-Za-z][A-Za-z\s]+$", ErrorMessage="Name must contains letters and space")]
        public string Name { get; set; }
        [Required(ErrorMessage ="Gender is required")]
        public string Gender { get; set; }
        [Required(ErrorMessage ="Designation is required")]
        [RegularExpression(@"^[A-Za-z][A-Za-z\s]+$",ErrorMessage ="Designation must contain only letters")]
        public string Designation {  get; set; }
        [Required(ErrorMessage ="Salary is required")]
        [Range(1,double.MaxValue,ErrorMessage ="Salary must be greater than 0")]
        public int Salary { get; set; }
        // Date of Birth
        [Required(ErrorMessage ="Date of Birth is Required")]
        [BindProperty,DataType(DataType.Date)]
        public DateTime DOB { get; set; }

        [ForeignKey("Department")]
        [Required(ErrorMessage ="Department is required")]
        [Range(1,3,ErrorMessage ="Department must be 1, 2 or 3")]
        public int DepartmentId { get; set; } 
        // Replaced Department with Department details
        public virtual Department Department { get; set; }  
 
    }
}
