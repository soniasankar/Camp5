﻿using DemoJune2024EmsSystem.Models;
using DemoJune2024EmsSystem.Repository;
using DemoJune2024EmsSystem.Service;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace DemoJune2024EmsSystem.Controllers
{
    public class EmployeeController : Controller
    {
        // Get data from Database
      //  private readonly  IEmployeeService _employeeService;
      private readonly IEmployeeRepository _employeeRepository;

        // DI
        public EmployeeController(IEmployeeRepository employeeRepository)
        {
            _employeeRepository = employeeRepository;   
        }
        // GET: EmployeeController
        // List All Employees
        public ActionResult Index() // Index.cshtml
        {
            // get 
            List<Employee> listOfEmployees = new List<Employee>();
            listOfEmployees = _employeeRepository.GetAllEmployees().ToList();
            return View(listOfEmployees);
        }

        // GET: EmployeeController/Details/5
        // Search By Id
        public ActionResult Details(int id)
        {
            Employee employee = _employeeRepository.GetEmployeeById(id);    
            return View(employee);
        }

        // GET: EmployeeController/Create
        // Insert - Display
        public ActionResult Create()
        {
            //show DropDoenList for Department
            ViewBag.Departments = _employeeRepository.GetAllDepartments();
            return View();
        }

        // POST: EmployeeController/Create
        // Insert for Submit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind] Employee employee)
        {
            try
            {
                // Validate DepartmentId
                if (employee.DepartmentId > 0)
                {
                    // Get Department
                    var department = _employeeRepository.GetDepartmentById(employee.DepartmentId);
                    employee.Department = department;
					_employeeRepository.AddEmployee(employee);  
				}
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: EmployeeController/Edit/5
        // Display - Edit
        public ActionResult Edit(int id)
        {
			ViewBag.Departments = _employeeRepository.GetAllDepartments();
			// Get a specific employee
			Employee employee = _employeeRepository.GetEmployeeById(id);
            return View(employee);
        }

        // POST: EmployeeController/Edit/5
        // Update - Edit
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, Employee employee)
        {
            try
            {
                //
                _employeeRepository.UpdateEmployee(employee);
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View(employee);
            }
        }

        // GET: EmployeeController/Delete/5
        // Display - Delete
        [HttpGet]
        public ActionResult Delete(int? id)
        {
            // Get a specific employee
			Employee employee = _employeeRepository.GetEmployeeById(id);
			return View(employee);
        }

		// POST: EmployeeController/Delete/5
		// Update - Delete
		//[HttpPost]
		//[ValidateAntiForgeryToken]
		//public ActionResult Delete(int id)
		//{
		//    try
		//    {
		//        _employeeRepository.DeleteEmployee(id); 
		//        return RedirectToAction(nameof(Index));
		//    }
		//    catch
		//    {
		//        return View();
		//    }
		//}
		[HttpPost]
		[ValidateAntiForgeryToken]
		public ActionResult Delete(int id)
		{
			try
			{
                // Fetch the employee from the database using the Id
                Employee employee = _employeeRepository.GetEmployeeById(id);
                if (employee == null)
                {
                    return Json(new {success= false , message="Employee not found."});  
                }
				_employeeRepository.DeleteEmployee(id);
                return Json(new { success = true, message="Employee deleted successfully."});
			}
			catch (Exception ex) 
			{
                return Json(new { success = false, messsage = "An error occured." });
			}
		}
	}
}
